document.addEventListener('DOMContentLoaded', function () {
    const startCourseButtons = document.querySelectorAll('.start-course');
    const startExamButtons = document.querySelectorAll('.start-exam');
    const viewReportLinks = document.querySelectorAll('.view-report');

    // Add event listeners for course and exam buttons
    startCourseButtons.forEach(function (button) {
        button.addEventListener('click', function () {
            // Replace this alert with your course starting logic
            alert('Starting the course...');
        });
    });

    startExamButtons.forEach(function (button) {
        button.addEventListener('click', function () {
            // Replace this alert with your exam starting logic
            alert('Starting the exam...');
        });
    });

    // Add event listeners for report links
    viewReportLinks.forEach(function (link) {
        link.addEventListener('click', function (event) {
            // Prevent the default link behavior (e.g., navigating to a new page)
            event.preventDefault();

            // Show an alert message when the link is clicked
            alert('Viewing the report...');
        });
    });
});
