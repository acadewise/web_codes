// JavaScript for handling the chat functionality

// Get DOM elements
const messageInput = document.getElementById("message-input");
const sendButton = document.getElementById("send-button");
const chatMessages = document.getElementById("chat-messages");

// Event listener for sending messages
sendButton.addEventListener("click", () => {
    const message = messageInput.value.trim();
    if (message !== "") {
        // Create a new message element and append it to the chat
        const messageElement = document.createElement("div");
        messageElement.className = "message";
        messageElement.textContent = message;
        chatMessages.appendChild(messageElement);

        // Clear the input field
        messageInput.value = "";

        // Scroll to the bottom to show the latest message
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }
});

// Event listener for sending messages when the Enter key is pressed
messageInput.addEventListener("keydown", (e) => {
    if (e.key === "Enter") {
        sendButton.click();
    }
});
