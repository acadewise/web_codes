document.addEventListener('DOMContentLoaded', function () {
    // Function to add a row to a table
    function addRowToTable(tableId, data) {
        const table = document.querySelector(`#${tableId} tbody`);
        const row = table.insertRow();
        for (const key in data) {
            if (data.hasOwnProperty(key)) {
                const cell = row.insertCell();
                cell.textContent = data[key];
            }
        }
    }

    // Function to handle form submissions
    function handleFormSubmit(event) {
        event.preventDefault(); // Prevents the form from submitting and reloading the page

        // Get form data
        const formData = new FormData(event.target);
        const feedbackData = {
            'Student Name': formData.get('student-name-input'),
            'Feedback': formData.get('feedback-input'),
        };

        // Add data to the feedback table
        addRowToTable('feedback-table', feedbackData);

        // Clear the form fields
        event.target.reset();
    }

    // Add an event listener to the feedback form
    const feedbackForm = document.querySelector('#feedback-form');
    feedbackForm.addEventListener('submit', handleFormSubmit);

    // ... (rest of the code) ...
});

document.addEventListener('DOMContentLoaded', function () {
    // Function to add a row to a table
    function addRowToTable(tableId, data) {
        const table = document.querySelector(`#${tableId} tbody`);
        const row = table.insertRow();
        for (const key in data) {
            if (data.hasOwnProperty(key)) {
                const cell = row.insertCell();
                cell.textContent = data[key];
            }
        }
    }

    // Function to handle form submissions for courses
    function handleCourseFormSubmit(event) {
        event.preventDefault(); // Prevents the form from submitting and reloading the page

        // Get form data
        const formData = new FormData(event.target);
        const courseData = {
            'Course Name': formData.get('course-name-input'),
            'Course Description': formData.get('course-desc-input'),
        };

        // Add data to the course table
        addRowToTable('course-table', courseData);

        // Clear the form field
        event.target.reset();
    }

    // Function to handle form submissions for progress tracking
    function handleProgressFormSubmit(event) {
        event.preventDefault(); // Prevents the form from submitting and reloading the page

        // Get form data
        const formData = new FormData(event.target);
        const progressData = {
            'Student Name': formData.get('student-name-input'),
            'Progress': formData.get('progress-input'),
        };

        // Add data to the progress table
        addRowToTable('progress-table', progressData);

        // Clear the form fields
        event.target.reset();
    }

    // Add event listeners to the course and progress forms
    const courseForm = document.querySelector('#course-form');
    courseForm.addEventListener('submit', handleCourseFormSubmit);

    const progressForm = document.querySelector('#progress-form');
    progressForm.addEventListener('submit', handleProgressFormSubmit);

    // ... (rest of the code) ...
});
